#!/bin/bash
echo "Proceso_simulado_de_alto_uso iniciado. PID=9999 (simulado)."
sleep 9999
