#!/bin/bash




: "${GAME_ROOT:?GAME_ROOT no seteado}"   
: "${STATE_FILE:?STATE_FILE no seteado}" 

#Gestión de Estado
function cargar_estado {
    	if [[ -f "$STATE_FILE" && -s "$STATE_FILE" ]]; then
        source "$STATE_FILE"
    else
        NIVEL_ACTUAL=1
        guardar_estado
    fi

    if ! [[ "$NIVEL_ACTUAL" =~ ^[0-9]+$ ]]; then
        NIVEL_ACTUAL=1
    fi

    export NIVEL_ACTUAL
}
function guardar_estado {
    echo "NIVEL_ACTUAL=$NIVEL_ACTUAL" > "$STATE_FILE"
}

function log_evento { 
#Bitácora
    local ACCION=$1
    echo "$(date '+%Y-%m-%d %H:%M:%S') | Nivel $NIVEL_ACTUAL | $ACCION" >> "$GAME_ROOT/servidor_simulado/bitacora.txt"
}

# Valida la entrada (solo acepta 4 dígitos de código)
function validar_entrada {
    local PROMPT="$1"
    local REGEX="^[0-9]{4}$" 
    local __resultvar="$2"

    while true; do
        read -p "$PROMPT [CÓDIGO 4 DÍGITOS / 2=LIBRETA]: " INPUT
 	
	INPUT="$(echo -n "$INPUT" | tr -d '[:space:]\r\n')"        
	if [ "$INPUT" = "2" ]; then
		mostrar_libreta		
		continue
	fi

	if [[ "$INPUT" =~ $REGEX ]]; then
            eval $__resultvar="$INPUT"
            return 0
        else
            echo "❌ ERROR: Entrada inválida. Debes ingresar un código numérico de 4 dígitos."
        fi
    done
}

#UX y Navegación ---

#libreta
function mostrar_libreta {
    clear
    echo "========================================================"
    echo "📓 LIBRETA DE COMANDOS CRÍTICOS (CÓDIGOS)"
    echo "========================================================"
    echo "Selecciona el código que mejor resuelve la tarea de análisis planteada."
    echo "En cada mision tendras que elgir el comando correcto atraves de un codigo de 4 digitos"
    
    echo "Vuelve a esta libreta siempre que quieras revisar los comandos a utilizar"
    echo "1010 | du / grep / sort     | Para identificar el archivo/directorio de **mayor tamaño**."
    echo "2020 | ps / grep            | Para buscar patrones de **usuario/proceso** en listados."
    echo "3030 | grep -c              | Para **contar** la cantidad de líneas que coinciden con un patrón."
    echo "4040 | grep | cut | sort | uniq | Para analizar logs, extraer **IPs** y contar su frecuencia."
    echo "5050 | grep | tee             | Para **guardar** la salida de un filtro en un nuevo archivo de texto."
    echo "6060 | chmod                  | Para **asegurar archivos** con permisos específicos (600)."
    echo "7070 | crontab              | Para programar una tarea de análisis/copia **periódica** (diaria)."
    echo "8080 | at                   | Para programar una tarea de limpieza **única** en el futuro."
    echo "1111 | ls -l | awk | tail   | Para borrar los últimos 10 archivos modificados (¡Incorrecto!)."
    echo "2222 | ifconfig | ping     | Para verificar la conexión de red (No aplica a análisis de archivos)."
    echo "3333 | rm -rf /             | Para eliminar recursivamente un directorio (¡Destructivo!)."
    echo "4444 | head -n 10           | Para ver solo las primeras 10 líneas de un archivo de texto."
    echo "5555 | whoami | id         | Para ver el usuario actual del sistema."
    echo "6666 | apt install apache   | Para instalar un paquete (No es una tarea de análisis)."
    echo "7777 | cat /etc/passwd      | Para mostrar el contenido de un archivo de configuración crítico."
    echo "8888 | gzip | tar           | Para comprimir varios archivos juntos."
    
    echo "========================================================"
    echo "Presiona [Enter] para volver al menú principal."
    read
}

function salir_juego {
    guardar_estado
    clear
    echo "¡Hasta pronto! Tu progreso se ha guardado en Nivel $NIVEL_ACTUAL."
    exit 0
}

function mostrar_menu {
    clear
    echo "╔═══════════════════════════════════════════════╗"
    echo "║          *** S E R V E R F I X E R *** ║"
    echo "║        Servidor Crítico de la NACIÓN (ITI)    ║"
    echo "╚═══════════════════════════════════════════════╝"
    
    if [[ "$NIVEL_ACTUAL" -eq 1 ]]; then
        echo "===================================================="
        echo "🚨 INTRODUCCIÓN:"
        echo "Un servidor vital del ITI ha sufrido un fallo. Como Admin,"
        echo "debes tomar decisiones rápidas basadas en el **análisis de archivos .txt**."
        echo "¡Cada elección repercute en tu destino como Tecnico de Servidores!"
        echo "===================================================="
    fi

    echo "Nivel Actual: $NIVEL_ACTUAL - Misión: $(get_mision_nombre)"
    echo "===================================================="
    echo "1) Iniciar / Continuar Misión"
    echo "2) Libreta"
    echo "3) Salir del Juego"
    echo ""

    read -p "Elige una opción: " OPCION
    
    case "$OPCION" in
        1) iniciar_mision ;;
        2) mostrar_libreta ;;
        3) salir_juego ;;
        *) echo "Entrada inválida. Presiona [Enter] para continuar." && read ;;
    esac
}

