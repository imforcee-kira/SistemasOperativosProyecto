#!/bin/bash




function check_decision {
    # Función de validación de decisiones
    local PROMPT=$1
    local CORRECT_CODE=$2
    local MISSION_NAME=$3

    echo "========================================================"
    echo "⏱️ MISIÓN $MISSION_NAME | Código correcto: $CORRECT_CODE"
    echo "========================================================"
    echo "$PROMPT"
    
    validar_entrada "Decisión ($MISSION_NAME): " CODIGO_INGRESADO

    if [[ "$CODIGO_INGRESADO" == "$CORRECT_CODE" ]]; then
        log_evento "MITIGACION: $MISSION_NAME - Correcto ($CODIGO_INGRESADO)"
        echo "✅ Decisión correcta. Mitigación: $MISSION_NAME."
        sleep 1
        return 0 
    else
        log_evento "MITIGACION: $MISSION_NAME - FALLO ($CODIGO_INGRESADO) vs ($CORRECT_CODE)"
        echo "❌ ¡ERROR CRÍTICO! Decisión incorrecta. El atacante escaló privilegios."
        sleep 3
        return 1 
    fi
}

function nivel2_start {
    clear
    echo ">>> INICIANDO MISIÓN 2: MITIGACIÓN <<<"
    sleep 2

    #Misiones nivel 2
    if ! check_decision "2.1 Debes analizar el archivo **access.txt**. ¿Qué comando usas para filtrar errores, cortar la **IP** (patrón numérico), ordenar y contar la frecuencia? (grep | cut | sort | uniq)" "4040" "2.1 IP ATACANTE" ; then
        return 1
    fi
    

    if ! check_decision "2.2 Debes tomar la salida del filtro y **guardar** esas líneas de evidencia en un nuevo archivo de texto. ¿Qué comando usas en la tubería? (tee)" "5050" "2.2 CREAR REPORTE" ; then
        return 1
    fi
    
  
    if ! check_decision "2.3 El reporte debe ser confidencial. ¿Qué comando utilizas para asegurar el archivo de texto con permisos de **solo lectura/escritura para el dueño (600)**? (chmod)" "6060" "2.3 ASEGURAR" ; then
        return 1
    fi

    echo ">>> MISIÓN 2: MITIGACIÓN COMPLETADA. <<<"
    sleep 2
    return 0 
}
