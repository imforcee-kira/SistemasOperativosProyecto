#!/bin/bash



function check_decision {
    # Función de validación de decisiones
    local PROMPT=$1
    local CORRECT_CODE=$2
    local MISSION_NAME=$3

    echo "========================================================"
    echo "⏱️ MISIÓN $MISSION_NAME | Código correcto: $CORRECT_CODE"
    echo "========================================================"
    echo "$PROMPT"
    
    validar_entrada "Decisión ($MISSION_NAME): " CODIGO_INGRESADO

    if [[ "$CODIGO_INGRESADO" == "$CORRECT_CODE" ]]; then
        log_evento "RECUPERACIÓN: $MISSION_NAME - Correcto ($CODIGO_INGRESADO)"
        echo "✅ Decisión correcta. La automatización es robusta."
        sleep 1
        return 0 
    else
        log_evento "RECUPERACIÓN: $MISSION_NAME - FALLO ($CODIGO_INGRESADO) vs ($CORRECT_CODE)"
        echo "❌ ¡ERROR CRÍTICO! Decisión incorrecta."
        echo "Los procedimientos automáticos fallaron en el reinicio del sistema. Fin del juego."
        sleep 3
        return 1 
    fi
}

function mostrar_final_bueno {
    	clear
    	echo "╔═══════════════════════════════════════════════╗"
    	echo "║          🏆 FINAL BUENO: SERVIDOR SALVADO 🏆      ║"
    	echo "╚═══════════════════════════════════════════════╝"
    	echo "¡Felicidades, Administrador! Tus decisiones precisas salvaron la información"
    	echo "de seguridad nacional. ServerFixer está 100% operativo."
    	log_evento "JUEGO COMPLETADO: FINAL BUENO."
	#reinicia el nivel una vez ya completado el juego.    
	NIVEL_ACTUAL=1
	guardar_estado

	echo ""
    	echo "Pulsa [Enter] para terminar."
    	read
    	return 0
}

function nivel3_start {
    clear
    echo ">>> INICIANDO MISIÓN 3: RECUPERACIÓN <<<"
    sleep 2

    #Misiones nivel 3
    if ! check_decision "3.1 El sistema debe tener un backup diario. ¿Qué comando utilizas para editar o crear una **tarea periódica** que analice y guarde archivos de texto? (cron)" "7070" "3.1 BACKUP CRON" ; then
        return 1
    fi
    
  
    if ! check_decision "3.2 Para liberar espacio, debes programar una tarea de limpieza **única** en el futuro cercano. ¿Qué comando usas para esta automatización no periódica? (at)" "8080" "3.2 LIMPIEZA AT" ; then
        return 1
    fi
    
    # Si respondio todo correctamente (Final Bueno)
    mostrar_final_bueno
    return 0 
}
