#!/bin/bash
# Nivel 1: Diagnóstico (Códigos 1010, 2020, 3030)

function check_decision {
local PROMPT="$1"
    local CORRECT_CODE="$2"
    local MISSION_NAME="$3"
    local CODIGO_INGRESADO

    echo "========================================================"
    echo "⏱️ MISIÓN $MISSION_NAME"
    echo "========================================================"
    echo "$PROMPT"

    validar_entrada "Decisión ($MISSION_NAME): " CODIGO_INGRESADO

    #Eliminar espacios y saltos de línea
    CODIGO_INGRESADO="$(echo -n "$CODIGO_INGRESADO" | tr -d '[:space:]\r\n')"

    if [[ "$CODIGO_INGRESADO" == "$CORRECT_CODE" ]]; then
        echo "✔️ Respuesta correcta."
        return 0
    else
        echo "❌ Respuesta incorrecta."
        return 1
    fi
}

function nivel1_start {
    clear
    echo ">>> INICIANDO MISIÓN 1: DIAGNÓSTICO <<<"
    sleep 2

    # Misiones nivel 1    
	if ! check_decision "1.1 El consumo de disco es crítico. ¿Qué comando ejecutas para saber cuál es el **nombre del archivo** que genera el consumo masivo?" 1010 "DIAGNOSTICO 1.1" ; then
        return 1
    fi
    
    
   if ! check_decision "1.2 Hay alta carga de CPU. Asumiendo que el usuario crítico es 'sadmin', ¿qué comando usas para buscar ese **patrón de usuario** y obtener su PID?" 2020 "DIAGNOSTICO 1.2"; then
        return 1
    fi
    
  
    if ! check_decision "1.3 Debes analizar el archivo **sistema.txt**. ¿Qué comando usas para saber la **cantidad exacta** de líneas que contienen el patrón 'CRITICAL'?" 3030 "DIAGNOSTICO 1.3" ; then
        return 1
    fi

    echo ">>> MISIÓN 1: DIAGNÓSTICO COMPLETADO. <<<"
    sleep 2
    return 0 
}
