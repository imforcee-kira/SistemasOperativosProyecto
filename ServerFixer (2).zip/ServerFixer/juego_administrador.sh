
#!/bin/bash

# Seteado de rutas globales
SCRIPT_DIR="$(cd -- "$(dirname "${BASH_SOURCE[0]}")" > /dev/null 2>&1 && pwd)"
export GAME_ROOT="$SCRIPT_DIR"
export STATE_FILE="$GAME_ROOT/estado_juego.txt"
export LIB_PATH="$GAME_ROOT/lib"

# Cargar funciones comunes y estado
source "$LIB_PATH/funciones_comunes.sh"

function get_mision_nombre {
    case "$NIVEL_ACTUAL" in
        1) echo "DIAGNÓSTICO (Códigos 1010-3030)" ;;
        2) echo "MITIGACIÓN (Códigos 4040-6060)" ;;
        3) echo "RECUPERACIÓN (Códigos 7070-8080)" ;;
        *) echo "¡JUEGO TERMINADO!" ;;
    esac
}

function mostrar_final_malo {
    	clear
    	echo "╔═══════════════════════════════════════════════╗"
    	echo "║          💀 FINAL MALO: FALLO NACIONAL 💀      ║"
    	echo "╚═══════════════════════════════════════════════╝"
    	echo "Tu última decisión incorrecta provocó un colapso. La misión ha fallado."
    	log_evento "JUEGO FALLIDO: FINAL MALO."
	
	NIVEL_ACTUAL=1
	guardar_estado   
    	echo ""
    	echo "Pulsa [Enter] para terminar."
    	read
    	return 0

}

function iniciar_mision {
    cargar_estado 

    # Carga y ejecución del nivel
    case "$NIVEL_ACTUAL" in
        1) source "$LIB_PATH/nivel1_Diagnostico.sh" && nivel1_start ;;
        2) source "$LIB_PATH/nivel2_mitigacion.sh" && nivel2_start ;;
        3) source "$LIB_PATH/nivel3_recuperacion.sh" && nivel3_start ;;
        *) NIVEL_ACTUAL=1; guardar_estado; source "$LIB_PATH/nivel1_Diagnostico.sh" && nivel1_start;;
    esac

    # Comprueba el resultado de la misión
    if [ "$?" -eq 0 ]; then
        NIVEL_ANTERIOR=$NIVEL_ACTUAL
        if [ "$NIVEL_ANTERIOR" -lt 3 ]; then
            ((NIVEL_ACTUAL++))
            echo "➡️ Has avanzado al nivel $NIVEL_ACTUAL"
            guardar_estado
        else
            mostrar_final_bueno
        fi
    else
        mostrar_final_malo
    fi
}

#Inicio del Juego
cargar_estado
log_evento "Juego ServerFixer iniciado / Sesión reanudada en Nivel $NIVEL_ACTUAL."

#Comprueba si hay algun nivel ya cargado para reanudar
echo ""
echo "==============================================="
echo " Progreso actual: Nivel $NIVEL_ACTUAL"
echo "==============================================="
echo "¿Deseas continuar desde tu última misión guardada?"
echo "1) Sí, continuar"
echo "2) No, empezar desde el nivel 1"
read -p "Elige una opción: " opcion_inicio

if [ "$opcion_inicio" = "2" ]; then
    NIVEL_ACTUAL=1
    guardar_estado
    echo "🔄 Progreso reiniciado. Empezarás desde el nivel 1."
    sleep 1.5
fi

# Bucle principal. luego de cada nivel completado vuelve al menu
while true; do
    mostrar_menu
done
